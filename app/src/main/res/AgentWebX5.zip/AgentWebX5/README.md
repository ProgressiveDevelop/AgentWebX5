# 说明
本项目是对AgentWebX5修改,原项目作者停止维护；在独自应用中使用，故对其进行修改维护。
## 原项目地址：
[AgentWebX5](https://github.com/Justson/AgentWebX5). 
## 修改内容
依赖环境改为AndroidX,更新依赖的libs
