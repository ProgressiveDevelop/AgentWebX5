package com.webx5;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import com.just.agentwebX5.AgentWebX5;
import com.just.agentwebX5.util.LogUtils;


public class AndroidInterface {
    private AgentWebX5 agentWebX5;
    private Context context;
    private Handler deliver = new Handler(Looper.getMainLooper());

    public AndroidInterface(AgentWebX5 agent, Context context) {
        this.agentWebX5 = agent;
        this.context = context;
    }

    @JavascriptInterface
    public void callAndroid(final String msg) {
        deliver.post(new Runnable() {
            @Override
            public void run() {
                Log.i("Info", "main Thread:" + Thread.currentThread());
                Toast.makeText(context.getApplicationContext(), "" + msg, Toast.LENGTH_LONG).show();
            }
        });
        LogUtils.getInstance().e("Info", "Thread:" + Thread.currentThread());
    }
}
