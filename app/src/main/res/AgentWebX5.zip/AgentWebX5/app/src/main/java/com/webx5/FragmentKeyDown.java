package com.webx5;

import android.view.KeyEvent;

public interface FragmentKeyDown {
    boolean onFragmentKeyDown(int keyCode, KeyEvent event);
}
