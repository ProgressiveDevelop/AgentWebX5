package com.just.agentwebX5.helpClass;

import com.just.agentwebX5.uploadFile.FileUploadMsgPO;

public class ChromeClientMsgCfg {
    private FileUploadMsgPO mFileUploadMsgConfig = new FileUploadMsgPO();

    public FileUploadMsgPO getFileUploadMsgConfig() {
        return mFileUploadMsgConfig;
    }
}
