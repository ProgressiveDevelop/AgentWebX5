package com.just.agentwebX5;


import com.just.agentwebX5.progress.IBaseProgressSpec;
import com.tencent.smtt.sdk.WebView;

/**
 * 进度控制接口
 */
public interface IndicatorController {
    void progress(WebView v, int newProgress);

    IBaseProgressSpec offerIndicator();
}
