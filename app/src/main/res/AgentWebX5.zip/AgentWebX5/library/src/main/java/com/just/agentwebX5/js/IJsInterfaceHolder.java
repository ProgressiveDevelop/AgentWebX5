package com.just.agentwebX5.js;

import androidx.collection.ArrayMap;

/**
 * Created by cenxiaozhong on 2017/5/13.
 * source CODE  https://github.com/Justson/AgentWebX5
 */

public interface IJsInterfaceHolder {

    IJsInterfaceHolder addJavaObjects(ArrayMap<String, Object> maps);

    IJsInterfaceHolder addJavaObject(String k, Object v);

    boolean checkObject(Object v);

}
