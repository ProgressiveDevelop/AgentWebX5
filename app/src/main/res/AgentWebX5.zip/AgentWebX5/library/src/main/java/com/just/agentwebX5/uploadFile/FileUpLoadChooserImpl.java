package com.just.agentwebX5.uploadFile;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import androidx.appcompat.app.AlertDialog;

import com.just.agentwebX5.ActionActivity;
import com.just.agentwebX5.util.AgentWebX5Utils;
import com.just.agentwebX5.util.LogUtils;
import com.permission.kit.OnPermissionListener;
import com.permission.kit.PermissionKit;
import com.tencent.smtt.sdk.ValueCallback;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebView;

import java.util.Queue;

/**
 * 选择文件接口实现类
 */
public class FileUpLoadChooserImpl implements IFileUploadChooser {
    private Activity mActivity;
    private ValueCallback<Uri> mUriValueCallback;
    private ValueCallback<Uri[]> mUriValueCallbacks;
    public static final int REQUEST_CODE = 0x254;
    private boolean isL;
    private JsChannelCallback mJsChannelCallback;
    private boolean jsChannel;
    private AlertDialog mAlertDialog;
    private static final String TAG = FileUpLoadChooserImpl.class.getSimpleName();
    private FileUploadMsgPO msgPO;
    private WebView mWebView;
    private boolean cameraState = false;

    public FileUpLoadChooserImpl(Builder builder) {
        this.mActivity = builder.mActivity;
        this.mUriValueCallback = builder.mUriValueCallback;
        this.mUriValueCallbacks = builder.mUriValueCallbacks;
        this.isL = builder.isL;
        this.jsChannel = builder.jsChannel;
        this.mJsChannelCallback = builder.mJsChannelCallback;
        this.msgPO = builder.mFileUploadMsgConfig;
        this.mWebView = builder.mWebView;
    }

    @Override
    public void openFileChooser() {
        if (!AgentWebX5Utils.isUIThread()) {
            AgentWebX5Utils.runInUiThread(new Runnable() {
                @Override
                public void run() {
                    openFileChooser();
                }
            });
        } else {
            openFileChooserInternal();
        }
    }

    /**
     * 打开上传选择对话框
     */
    private void openFileChooserInternal() {
        if (mAlertDialog == null) {
            mAlertDialog = new AlertDialog.Builder(mActivity)//
                    .setSingleChoiceItems(msgPO.getMedias(), -1, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            mAlertDialog.dismiss();
                            checkPermission(which);
                        }
                    })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override
                        public void onCancel(DialogInterface dialog) {
                            cancel();
                        }
                    }).create();
        }
        mAlertDialog.show();
    }

    /**
     * 检查权限
     *
     * @param which 相机&文件
     */
    private void checkPermission(final int which) {
        //请求权限
        PermissionKit.getInstance().requestPermission(mActivity, 1000, new OnPermissionListener() {
            @Override
            public void onSuccess(int requestCode, String... permissions) {
                if (which == 1) {
                    cameraState = false;
                    openFileChooserAction();
                } else {
                    cameraState = true;
                    openCameraAction();
                }
            }

            @Override
            public void onFail(int requestCode, String... permissions) {
                //授权失败后再次操作
                PermissionKit.getInstance().guideSetting(mActivity, true, requestCode, null, permissions);
            }
        }, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA);
    }

    /**
     * 打开文件
     */
    private void openFileChooserAction() {
        ActionPO mAction = new ActionPO();
        mAction.setAction(ActionPO.ACTION_FILE);
        ActionActivity.setFileDataListener(getFileDataListener());
        mActivity.startActivity(new Intent(mActivity, ActionActivity.class).putExtra(ActionActivity.KEY_ACTION, mAction));
    }

    /**
     * 打开相机
     */
    private void openCameraAction() {
        ActionPO mAction = new ActionPO();
        mAction.setAction(ActionPO.ACTION_CAMERA);
        ActionActivity.setFileDataListener(this.getFileDataListener());
        ActionActivity.start(mActivity, mAction);
    }

    private IFileDataListener getFileDataListener() {
        return new IFileDataListener() {
            @Override
            public void onFileDataResult(int requestCode, int resultCode, Intent data) {
                LogUtils.getInstance().e(TAG, "request:" + requestCode + "  resultCode:" + resultCode);
                fetchFilePathFromIntent(requestCode, resultCode, data);
            }
        };
    }

    @Override
    public void fetchFilePathFromIntent(int requestCode, int resultCode, Intent data) {
        LogUtils.getInstance().e(TAG, "request:" + requestCode + "  result:" + resultCode + "  data:" + data);
        if (REQUEST_CODE != requestCode) {
            return;
        }
        if (resultCode == Activity.RESULT_CANCELED) {
            cancel();
            return;
        }
        if (resultCode == Activity.RESULT_OK) {
            if (isL) {
                handleAboveL(cameraState ? new Uri[]{data.getParcelableExtra(ActionActivity.KEY_URI)} : processData(data));
            } else if (jsChannel) {
                convertFileAndCallBack(cameraState ? new Uri[]{data.getParcelableExtra(ActionActivity.KEY_URI)} : processData(data));
            } else {
                if (cameraState && mUriValueCallback != null) {
                    mUriValueCallback.onReceiveValue((Uri) data.getParcelableExtra(ActionActivity.KEY_URI));
                } else {
                    handleBelowLData(data);
                }
            }
        }
    }

    private void cancel() {
        if (jsChannel) {
            mJsChannelCallback.call(null);
            return;
        }
        if (mUriValueCallback != null) {
            mUriValueCallback.onReceiveValue(null);
        }
        if (mUriValueCallbacks != null) {
            mUriValueCallbacks.onReceiveValue(null);
        }
    }


    private void handleBelowLData(Intent data) {
        Uri mUri = data == null ? null : data.getData();
        LogUtils.getInstance().e(TAG, "handleBelowLData  -- >uri:" + mUri + "  mUriValueCallback:" + mUriValueCallback);
        if (mUriValueCallback != null) {
            mUriValueCallback.onReceiveValue(mUri);
        }
    }

    private Uri[] processData(Intent data) {
        String target = data.getDataString();
        if (!TextUtils.isEmpty(target)) {
            return new Uri[]{Uri.parse(target)};
        } else {
            return null;
        }
    }

    private void convertFileAndCallBack(final Uri[] uris) {
        String[] paths;
        if (uris == null || uris.length == 0 || (paths = AgentWebX5Utils.uriToPath(mActivity, uris)) == null || paths.length == 0) {
            mJsChannelCallback.call(null);
            return;
        }
        new CovertFileThread(this.mJsChannelCallback, paths).start();
    }

    private void handleAboveL(Uri[] datas) {
        if (mUriValueCallbacks != null) {
            mUriValueCallbacks.onReceiveValue(datas == null ? new Uri[]{} : datas);
        }
    }


    static class CovertFileThread extends Thread {
        private JsChannelCallback mJsChannelCallback;
        private String[] paths;

        private CovertFileThread(JsChannelCallback jsChannelCallback, String[] paths) {
            this.mJsChannelCallback = jsChannelCallback;
            this.paths = paths;
        }

        @Override
        public void run() {
            try {
                Queue<FilePO> mQueue = AgentWebX5Utils.convertFile(paths);
                String result = AgentWebX5Utils.convertFileParcelObjectsToJson(mQueue);
                LogUtils.getInstance().e(TAG, "result:" + result);
                if (mJsChannelCallback != null) {
                    mJsChannelCallback.call(result);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public interface JsChannelCallback {
        void call(String value);
    }

    /**
     * 构造器
     */
    public static final class Builder {
        private Activity mActivity;
        private ValueCallback<Uri> mUriValueCallback;
        private ValueCallback<Uri[]> mUriValueCallbacks;
        private boolean isL = false;
        private JsChannelCallback mJsChannelCallback;
        private boolean jsChannel = false;
        private FileUploadMsgPO mFileUploadMsgConfig;
        private WebView mWebView;

        public Builder setActivity(Activity activity) {
            mActivity = activity;
            return this;
        }

        public Builder setUriValueCallback(ValueCallback<Uri> uriValueCallback) {
            mUriValueCallback = uriValueCallback;
            isL = false;
            jsChannel = false;
            mUriValueCallbacks = null;
            mJsChannelCallback = null;
            return this;
        }

        public Builder setUriValueCallbacks(ValueCallback<Uri[]> uriValueCallbacks) {
            mUriValueCallbacks = uriValueCallbacks;
            isL = true;
            mUriValueCallback = null;
            mJsChannelCallback = null;
            jsChannel = false;
            return this;
        }


        public Builder setFileChooserParams(WebChromeClient.FileChooserParams fileChooserParams) {
            return this;
        }

        public Builder setJsChannelCallback(JsChannelCallback jsChannelCallback) {
            mJsChannelCallback = jsChannelCallback;
            jsChannel = true;
            mUriValueCallback = null;
            mUriValueCallbacks = null;
            return this;
        }


        public Builder setFileUploadMsgConfig(FileUploadMsgPO fileUploadMsgConfig) {
            mFileUploadMsgConfig = fileUploadMsgConfig;
            return this;
        }


        public Builder setWebView(WebView webView) {
            mWebView = webView;
            return this;
        }

        public FileUpLoadChooserImpl build() {
            return new FileUpLoadChooserImpl(this);
        }
    }

}
