package com.just.agentwebX5.progress;

/**
 *
 */

public interface IProgressLifeCyclic {

    void showProgressBar();

    void setProgressBar(int newProgress);

    void finish();
}
