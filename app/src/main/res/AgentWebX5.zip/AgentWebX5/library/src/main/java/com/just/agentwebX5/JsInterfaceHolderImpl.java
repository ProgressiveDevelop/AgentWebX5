package com.just.agentwebX5;

import androidx.collection.ArrayMap;

import android.util.Log;

import com.just.agentwebX5.js.IJsInterfaceHolder;
import com.tencent.smtt.sdk.WebView;

import java.util.Map;
import java.util.Set;

/**
 *
 */

public class JsInterfaceHolderImpl extends JsBaseInterfaceHolder {


    private WebView mWebView;

    public static JsInterfaceHolderImpl getJsInterfaceHolder(WebView webView, AgentWebX5.SecurityType securityType) {
        return new JsInterfaceHolderImpl(webView, securityType);
    }

    private JsInterfaceHolderImpl(WebView webView, AgentWebX5.SecurityType securityType) {
        super(securityType);
        this.mWebView = webView;
    }

    @Override
    public IJsInterfaceHolder addJavaObjects(ArrayMap<String, Object> maps) {
        if (!checkSecurity()) {
            return this;
        }
        Set<Map.Entry<String, Object>> sets = maps.entrySet();
        for (Map.Entry<String, Object> mEntry : sets) {
            Object v = mEntry.getValue();
            boolean t = checkObject(v);
            if (!t) {
                throw new JsInterfaceObjectException("this object has not offer method javascript to call ,please check addJavascriptInterface annotation was be added");
            } else {
                addJavaObjectDirect(mEntry.getKey(), v);
            }
        }
        return this;
    }

    @Override
    public IJsInterfaceHolder addJavaObject(String k, Object v) {
        if (!checkSecurity()) {
            return this;
        }
        boolean t = checkObject(v);
        if (!t) {
            throw new JsInterfaceObjectException("this object has not offer method javascript to call , please check addJavascriptInterface annotation was be added");
        } else {
            addJavaObjectDirect(k, v);
        }
        return this;
    }

    private IJsInterfaceHolder addJavaObjectDirect(String k, Object v) {
        this.mWebView.addJavascriptInterface(v, k);
        return this;
    }

}
