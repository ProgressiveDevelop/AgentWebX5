package com.just.agentwebX5.progress;

public interface IProgressSpec {
    void reset();

    void setProgress(int newProgress);
}
