package com.just.agentwebX5.js;

import android.webkit.ValueCallback;

/**
 */

public interface IJsEntraceAccess extends IQuickCallJs {

    void callJs(String js, ValueCallback<String> callback);

    void callJs(String js);
}
