package com.just.agentwebX5;


public interface IProvider<T> {
    T provide();
}
