package com.just.agentwebX5.uploadFile;

/**
 *
 */

public interface IFileUploadPop<T> {
    T pop();
}
