package com.just.agentwebX5;

public class HookManager {

    public static AgentWebX5 hookAgentWeb(AgentWebX5 agentWebX5, AgentWebX5.AgentBuilder agentBuilder) {
        return agentWebX5;
    }

    public static AgentWebX5 hookAgentWeb(AgentWebX5 agentWebX5, AgentWebX5.AgentBuilderFragment agentBuilder) {
        return agentWebX5;
    }

}
