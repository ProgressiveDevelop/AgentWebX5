package com.just.agentwebX5.helpClass;

/**
 * Created by cenxiaozhong on 2017/7/7.
 */

public final class DefaultMsgConfig {
    /**
     * 下载配置
     */
    private DownLoadMsgConfig mDownLoadMsgConfig;

    public DefaultMsgConfig() {
        mDownLoadMsgConfig = new DownLoadMsgConfig();
    }

    public DownLoadMsgConfig getDownLoadMsgConfig() {
        return mDownLoadMsgConfig;
    }

    /**
     *
     */
    private ChromeClientMsgCfg mChromeClientMsgCfg = new ChromeClientMsgCfg();

    public ChromeClientMsgCfg getChromeClientMsgCfg() {
        return mChromeClientMsgCfg;
    }

    private WebViewClientMsgCfg mWebViewClientMsgCfg = new WebViewClientMsgCfg();

    public WebViewClientMsgCfg getWebViewClientMsgCfg() {
        return mWebViewClientMsgCfg;
    }

}
