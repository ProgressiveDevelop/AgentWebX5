package com.just.agentwebX5.progress;


public interface IBaseProgressSpec extends IProgressSpec {
    void show();

    void hide();
}
