package com.just.agentwebX5;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.just.agentwebX5.permission.IPermissionRequestListener;
import com.just.agentwebX5.uploadFile.ActionPO;
import com.just.agentwebX5.uploadFile.IFileDataListener;
import com.just.agentwebX5.util.AgentWebX5Utils;
import com.just.agentwebX5.util.LogUtils;
import com.permission.kit.PermissionActivity;

import java.io.File;

import static android.provider.MediaStore.EXTRA_OUTPUT;
import static com.just.agentwebX5.uploadFile.FileUpLoadChooserImpl.REQUEST_CODE;


/**
 *
 */
public class ActionActivity extends PermissionActivity {
    public static final String KEY_ACTION = "KEY_ACTION";
    public static final String KEY_URI = "KEY_URI";
    public static final String KEY_FROM_INTENTION = "KEY_FROM_INTENTION";
    private static IPermissionRequestListener mPermissionListener;
    private static IFileDataListener mFileDataListener;
    private static final String TAG = ActionActivity.class.getSimpleName();
    private ActionPO mAction;

    /**
     * @param activity 上下文
     * @param action   Action 对象
     */
    public static void start(Activity activity, ActionPO action) {
        Intent mIntent = new Intent(activity, ActionActivity.class);
        mIntent.putExtra(KEY_ACTION, action);
        activity.startActivity(mIntent);
    }

    /**
     * @param fileDataListener
     */
    public static void setFileDataListener(IFileDataListener fileDataListener) {
        mFileDataListener = fileDataListener;
    }

    /**
     * @param permissionListener
     */
    public static void setPermissionListener(IPermissionRequestListener permissionListener) {
        mPermissionListener = permissionListener;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        mAction = intent.getParcelableExtra(KEY_ACTION);
        if (mAction == null) {
            finish();
        }
        //请求权限
        if (mAction.getAction() == ActionPO.ACTION_PERMISSION) {
            permission(mAction);
        } else if (mAction.getAction() == ActionPO.ACTION_CAMERA) {
            realOpenCamera();
        } else {
            fetchFile();
        }
    }

    private void fetchFile() {
        if (mFileDataListener == null) {
            finish();
        }
        openRealFileChooser();
    }

    private void openRealFileChooser() {
        if (mFileDataListener == null) {
            finish();
            return;
        }
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        this.startActivityForResult(Intent.createChooser(i, "File Chooser"), REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        LogUtils.getInstance().e(TAG, "mFileDataListener:" + mFileDataListener);
        if (requestCode == REQUEST_CODE) {
            if (mFileDataListener != null) {
                mFileDataListener.onFileDataResult(requestCode, resultCode, mUri != null ? new Intent().putExtra(KEY_URI, mUri) : data);
            }
            mFileDataListener = null;
            finish();
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    private void permission(ActionPO action) {
        String[] permissions = action.getPermissions();
        if (permissions == null) {
            mPermissionListener = null;
            finish();
            return;
        }
        LogUtils.getInstance().e(TAG, "requestPermissions:" + permissions[0]);
        if (mPermissionListener != null) {
            requestPermissions(permissions, 1);
        }
    }

    private Uri mUri;

    private void realOpenCamera() {
        try {
            if (mFileDataListener == null) {
                finish();
            }
            File mFile = AgentWebX5Utils.createImageFile(this);
            if (mFile == null) {
                mFileDataListener.onFileDataResult(REQUEST_CODE, Activity.RESULT_CANCELED, null);
                mFileDataListener = null;
                finish();
            }
            Intent intent = AgentWebX5Utils.getIntentCaptureCompat(this, mFile);
            LogUtils.getInstance().e(TAG, "listener:" + mFileDataListener + "  file:" + mFile.getAbsolutePath());
            // 指定开启系统相机的Action
            mUri = intent.getParcelableExtra(EXTRA_OUTPUT);
            this.startActivityForResult(intent, REQUEST_CODE);
        } catch (Throwable throwable) {
            LogUtils.getInstance().e(TAG, "找不到系统相机");
            mFileDataListener.onFileDataResult(REQUEST_CODE, Activity.RESULT_CANCELED, null);
            mFileDataListener = null;
            throwable.printStackTrace();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (mPermissionListener != null) {
            Bundle mBundle = new Bundle();
            mBundle.putInt(KEY_FROM_INTENTION, mAction.getFromIntention());
            mPermissionListener.onRequestPermissionsResult(permissions, grantResults, mBundle);
        }
        mPermissionListener = null;
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mFileDataListener = null;
        mPermissionListener = null;
    }
}
