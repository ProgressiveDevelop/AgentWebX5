package com.just.agentwebX5.uploadFile;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Arrays;

/**
 * Intent意图动作
 */
public class ActionPO implements Parcelable {
    public transient static final int ACTION_PERMISSION = 1;
    public transient static final int ACTION_FILE = 2;
    public transient static final int ACTION_CAMERA = 3;
    /**
     * 权限
     */
    private String[] permissions;
    /**
     * 动作
     */
    private int action;

    private int fromIntention;

    public String[] getPermissions() {
        return permissions;
    }

    public void setPermissions(String[] permissions) {
        this.permissions = permissions;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public ActionPO setFromIntention(int fromIntention) {
        this.fromIntention = fromIntention;
        return this;
    }

    public int getFromIntention() {
        return fromIntention;
    }

    public static ActionPO createPermissionsAction(String[] permissions) {
        ActionPO mAction = new ActionPO();
        mAction.setAction(ACTION_PERMISSION);
        mAction.setPermissions(permissions);
        return mAction;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(this.permissions);
        dest.writeInt(this.action);
        dest.writeInt(this.fromIntention);
    }

    public ActionPO() {
    }

    protected ActionPO(Parcel in) {
        this.permissions = in.createStringArray();
        this.action = in.readInt();
        this.fromIntention = in.readInt();
    }

    public static final Creator<ActionPO> CREATOR = new Creator<ActionPO>() {
        @Override
        public ActionPO createFromParcel(Parcel source) {
            return new ActionPO(source);
        }

        @Override
        public ActionPO[] newArray(int size) {
            return new ActionPO[size];
        }
    };
}
