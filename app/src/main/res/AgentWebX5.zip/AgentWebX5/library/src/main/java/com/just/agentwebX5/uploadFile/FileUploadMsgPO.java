package com.just.agentwebX5.uploadFile;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 上传文件选择配置
 */
public class FileUploadMsgPO implements Parcelable {
    private String[] medias = new String[]{"相机", "文件选择器"};

    public FileUploadMsgPO() {
    }

    protected FileUploadMsgPO(Parcel in) {
        medias = in.createStringArray();
    }

    public static final Creator<FileUploadMsgPO> CREATOR = new Creator<FileUploadMsgPO>() {
        @Override
        public FileUploadMsgPO createFromParcel(Parcel in) {
            return new FileUploadMsgPO(in);
        }

        @Override
        public FileUploadMsgPO[] newArray(int size) {
            return new FileUploadMsgPO[size];
        }
    };

    public void setMedias(String[] medias) {
        this.medias = medias;
    }

    public String[] getMedias() {
        return medias;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(medias);
    }
}
