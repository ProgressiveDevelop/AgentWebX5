package com.just.agentwebX5;

/**
 * 事件拦截器
 */
public interface IEventInterceptor {
    boolean event();
}
