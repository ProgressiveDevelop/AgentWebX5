package com.just.agentwebX5;

import android.os.Handler;
import android.os.Looper;
import android.webkit.ValueCallback;

import com.tencent.smtt.sdk.WebView;


/**
 *
 */

public class JsEntraceAccessImpl extends BaseJsEntraceAccess {

    private Handler mHandler = new Handler(Looper.getMainLooper());

    public static JsEntraceAccessImpl getInstance(WebView webView) {
        return new JsEntraceAccessImpl(webView);
    }

    private JsEntraceAccessImpl(WebView webView) {
        super(webView);
    }

    private void callSafeCallJs(final String s, final ValueCallback valueCallback) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                callJs(s, valueCallback);
            }
        });
    }

    @Override
    public void callJs(String params, final ValueCallback<String> callback) {
        if (Thread.currentThread() != Looper.getMainLooper().getThread()) {
            callSafeCallJs(params, callback);
            return;
        }
        super.callJs(params, callback);
    }

}
